// Copyright (c) 2026 ScratchBird Software Inc.
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
//
// SPDX-License-Identifier: MPL-2.0

#pragma once

#include "agent_runtime.hpp"

// SEARCH_KEY: SB_AGENT_RUNTIME_INSTANCE_STORE
// Durable agent instance state is represented by AgentInstanceRecord and the
// SerializeAgentInstanceRecord/RestoreAgentInstanceRecord contract.
